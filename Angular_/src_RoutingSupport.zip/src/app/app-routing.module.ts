import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TechnologyComponent } from './technology/technology.component';
import { BooksComponent } from './books/books.component';
import { WrongComponent } from './wrong/wrong.component';
const routes1: Routes = [
  { path : 'tech',component : TechnologyComponent},
  { path : 'book',component : BooksComponent},
  //default routing
  { path : '',component : BooksComponent },
  //wildcard routing
  { path : '**',component :  WrongComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes1)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
