import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrong',
  templateUrl: './wrong.component.html',
  styleUrls: ['./wrong.component.css']
})
export class WrongComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
