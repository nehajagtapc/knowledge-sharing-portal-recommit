import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BatchesComponent } from './batches/batches.component';
import { SubjectsComponent } from './subjects/subjects.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { InvalidComponent } from './invalid/invalid.component';

const routes: Routes = [
  {path : 'batch',component : BatchesComponent},
  {path : 'sub',component : SubjectsComponent},
  {path : 'about',component : AboutusComponent},
  {path : '',component : AboutusComponent},
//default aah varch
  {path : '**',component : InvalidComponent}
//invalid
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
