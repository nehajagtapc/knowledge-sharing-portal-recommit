
export function Display(student:any)
{
    return student + ' welcome to Marvellous Infosystems'
}