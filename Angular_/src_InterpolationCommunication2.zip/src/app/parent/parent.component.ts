import { Component,EventEmitter, OnInit,Output,} from '@angular/core';


@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit{
  
  @Output() public Myevent = new EventEmitter();
  public Message ="Hello parent";
  public SendEvent(){
    this.Myevent.emit(this.Message);
  }

  constructor(){}
  ngOnInit(): void {
    
  }

}