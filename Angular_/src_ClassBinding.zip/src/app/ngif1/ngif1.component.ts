import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngif1',
  templateUrl: './ngif1.component.html',
  styleUrls: ['./ngif1.component.css']
})

export class Ngif1Component 
{
  public flag = true;
  public Food = false;
  
}
