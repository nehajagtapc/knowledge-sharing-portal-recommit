import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ngswitch1Component } from './ngswitch1.component';

describe('Ngswitch1Component', () => {
  let component: Ngswitch1Component;
  let fixture: ComponentFixture<Ngswitch1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Ngswitch1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Ngswitch1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
