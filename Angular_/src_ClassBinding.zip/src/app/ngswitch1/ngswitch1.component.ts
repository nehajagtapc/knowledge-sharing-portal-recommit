import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngswitch1',
  templateUrl: './ngswitch1.component.html',
  styleUrls: ['./ngswitch1.component.css']
})

export class Ngswitch1Component  {

  public Batch = "Python";


}
