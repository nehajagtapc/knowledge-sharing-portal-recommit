import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MarvellousComponent } from './marvellous/marvellous.component';
import { NgforComponent } from './ngfor/ngfor.component';
import { Ngif1Component } from './ngif1/ngif1.component';
import { Ngswitch1Component } from './ngswitch1/ngswitch1.component';


@NgModule({
  declarations: [
    AppComponent,
    MarvellousComponent,
    NgforComponent,
    Ngif1Component,
    Ngswitch1Component,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
