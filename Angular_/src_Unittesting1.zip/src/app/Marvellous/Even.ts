export function ChkEven(no : number){
    if(no %2 ==0){
        return 1;
    }
    else{
        return 0;
    }
}