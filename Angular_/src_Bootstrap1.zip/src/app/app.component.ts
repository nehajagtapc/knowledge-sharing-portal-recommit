import {Component ,Input, OnInit} from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles : 
[`
    :host .alert-custom {
      color: black;
      background-color: #dcdcdc;
      border-color: #dcdcdc;
    }

    #mytextbox1 {margin-left : 10px;}
    #mytextbox2 {margin-right : 100px;}
    #mytextbox3 {margin-left : 10px;}
  `]

})

/*@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css' ]
})*/


export class AppComponent {
  title = "Hello";
  public Name : any;
  public value : any ;

  public Send(data : any){
    this.value = data;
  }
  myFormData(data : any){
    console.log(data.value);
  }
  
}

